﻿public enum PlayerType
{
    PlayerOne,
    PlayerTwo
}
public enum GameChoice // Player One's game choice enum
{
    PullUp,
    Treadmill,
    PunchingBag,
    Rest
}